package logic

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"

	"learningplatform/internal/app/user"
	"learningplatform/internal/model"
	"learningplatform/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type LoginLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewLoginLogic(ctx context.Context, svcCtx *svc.ServiceContext) *LoginLogic {
	return &LoginLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

// loginTokenTTL 登录 token 在 Redis 中的有效期（秒），24 小时
const loginTokenTTL = 24 * 3600

// Login 登录业务逻辑（主流 Redis 会话方案）：
// 1. 校验用户名密码（数据来自 MySQL 用户表）
// 2. 校验通过后生成随机 token（32 字节十六进制，不可预测）
// 3. 把会话信息（用户名 + 昵称）以 JSON 写入 Redis，TTL 24 小时
// 4. 返回 token 给前端，后续请求带 Authorization: Bearer {token}
func (l *LoginLogic) Login(req *user.LoginRequest) (resp *user.LoginResponse, err error) {
	ip := clientIPOf(l.ctx)
	guard := loginGuardOf(l.svcCtx)

	// 0. 先看是否已被锁定（同一 IP + 用户名连续失败 5 次，锁 10 分钟）
	if guard.Locked(ip, req.Username) {
		return nil, user.ErrTooManyAttempts
	}

	// 1. 校验用户名密码
	if !l.svcCtx.UserStore.Verify(req.Username, req.Password) {
		// 记录一次失败；第 5 次起后续请求会被上面的 Locked 拦住
		guard.Fail(ip, req.Username)
		return nil, user.ErrBadCredentials
	}
	// 登录成功：清空失败计数
	guard.Success(ip, req.Username)

	// 2. 生成随机 token（crypto/rand，比拼接时间戳更安全，主流的做法）
	token, err := generateLoginToken()
	if err != nil {
		return nil, errors.New("令牌生成失败")
	}

	// 3. 查用户信息（取昵称，构造会话）
	u := l.svcCtx.UserStore.GetUser(req.Username)
	if u == nil {
		return nil, errors.New("用户信息读取失败")
	}

	// 3.1 兼容老数据：如果库中还是明文密码，登录成功后自动升级为 bcrypt 哈希
	if !l.svcCtx.UserStore.IsBcrypted(req.Username) {
		_ = l.svcCtx.UserStore.UpgradePasswordHash(req.Username, req.Password)
	}

	// 4. 会话信息序列化为 JSON 写入 Redis
	// key = login:token:{token}，value = {"id":..., "username":..., "nickname":..., "role":...}
	// id 带上后，业务接口不必每请求再查一次 users 表确认身份。
	session := model.SessionUser{Id: u.Id, Username: u.Username, Nickname: u.Nickname, Role: u.Role}
	data, err := json.Marshal(session)
	if err != nil {
		return nil, errors.New("会话序列化失败")
	}
	if err := l.svcCtx.Redis.Setex(user.SessionKeyPrefix+token, string(data), loginTokenTTL); err != nil {
		return nil, errors.New("登录状态写入失败")
	}

	// 5. 返回登录结果（带上角色，前端据此控制"创建班级"等入口；
	//    mustChangePassword 让前端在进入首页前拦住初始密码用户）
	return &user.LoginResponse{
		Token:              token,
		Username:           req.Username,
		Role:               u.Role,
		MustChangePassword: u.MustChangePassword,
	}, nil
}

// errEmptyBody 登录请求体为空或缺少必填字段。
var errEmptyBody = errors.New("用户名和密码不能为空")

// ParseLoginJSON 宽松解析登录请求体：空 body 返回错误，但不做 required 校验
// （交给逻辑层判断），这样"少传字段"会得到可读的中文提示而不是框架英文报错。
func ParseLoginJSON(r *http.Request, v *user.LoginRequest) error {
	body, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
	if err != nil {
		return err
	}
	if len(body) == 0 {
		return errEmptyBody
	}
	if err := json.Unmarshal(body, v); err != nil {
		return err
	}
	if strings.TrimSpace(v.Username) == "" || v.Password == "" {
		return errEmptyBody
	}
	return nil
}

// clientIPOf 从 context 取客户端 IP（登录 handler 会写入）。
// 取不到时返回空串，key 里会用 "unknown" 兜底，不影响限流生效。
func clientIPOf(ctx context.Context) string {
	if v, ok := ctx.Value(user.ClientIPKey).(string); ok {
		return v
	}
	return ""
}

// generateLoginToken 生成 32 字节的随机 token（十六进制 64 位）。
// 使用 crypto/rand 安全随机源，避免 token 被猜测。
func generateLoginToken() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}
