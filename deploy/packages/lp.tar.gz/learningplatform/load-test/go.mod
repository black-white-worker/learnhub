module loadtest

go 1.27.2
