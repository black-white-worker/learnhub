ALTER TABLE agent_task ADD COLUMN IF NOT EXISTS plan_preview TEXT;
