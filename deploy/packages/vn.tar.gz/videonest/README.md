# VideoNest

[![Java](https://img.shields.io/badge/Java-21-orange)]()
[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-4.1-green)]()
[![Vue](https://img.shields.io/badge/Vue-3.x-42b883)]()
[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-3178c6)]()
[![MySQL](https://img.shields.io/badge/MySQL-8.4-blue)]()
[![Redis](https://img.shields.io/badge/Redis-7.4-red)]()
[![RabbitMQ](https://img.shields.io/badge/RabbitMQ-3.13-ff6600)]()
[![MinIO](https://img.shields.io/badge/MinIO-object%20storage-yellow)]()
[![Docker](https://img.shields.io/badge/Docker%20Compose-ready-2496ed)]()
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen)]()

> 一个面向学习、作品展示与小型社区的全栈视频平台：从上传、转码、审核到播放、互动、资源治理的完整闭环。

VideoNest 以 **Vue 3 + Spring Boot** 为核心，采用模块化单体架构，覆盖视频从上传、转码、审核到发布、播放、互动和资源清理的完整生命周期。首页提供轮换视觉横幅、关键词搜索、分区筛选和热门内容流；创作者与管理员分别在个人中心和管理后台完成后续操作。

后端的 HTTP 状态码、JWT 撤销、认证限流、Flyway 与 Transactional Outbox 设计边界见 [后端可靠性设计](docs/backend-reliability-design.md)。

![VideoNest 首页](https://cdn.jsdelivr.net/gh/black-white-build/Learn@main/docs/images/home.jpg)

![VideoNest 投稿发布页](https://cdn.jsdelivr.net/gh/black-white-build/Learn@main/docs/images/upload.jpg)

![VideoNest 视频详情页](https://cdn.jsdelivr.net/gh/black-white-build/Learn@main/docs/images/video-detail.jpg)

## 亮点

- 完整视频链路：上传原视频、RabbitMQ 异步转码、审核发布、多清晰度播放与延迟清理。
- 多级缓存读路径：视频列表 Caffeine 本地缓存 + SWR 异步刷新、Redis ZSet 热榜与本地短缓存、播放量 Redis 原子累计与 MySQL 批量回写、MinIO 直连播放。
- 可靠异步任务：Transactional Outbox 事务发件箱、发布确认、消费重试、死信队列、事件幂等、可续期 Redis 锁（看门狗自动续期）、转码卡死兜底扫描与人工重投。
- 社区与管理：注册登录、JWT 鉴权与撤销、认证限流、点赞收藏、嵌套评论与回复、关注通知、视频二维码/链接/QQ 分享、管理员用户管理与密码重置、死信与内容审核后台。
- 资源治理：上传后未投稿文件定时清理、回收站延迟清理、MinIO staging 前缀生命周期过期。
- 一键运行：Docker Compose 编排前端、后端、MySQL、Redis、RabbitMQ、MinIO 与 Nginx。

## 架构

```mermaid
flowchart LR
    U["浏览器"] --> N["Nginx / Vue 3"]
    N --> B["Spring Boot API"]
    B --> DB["MySQL"]
    B --> R["Redis"]
    B --> MQ["RabbitMQ"]
    B --> O["MinIO"]
    MQ --> W["转码、通知、延迟任务消费者"]
    W --> F["FFmpeg"]
    W --> DB
    W --> R
    W --> O
    U -->|"临时签名 URL"| O
```

项目采用模块化单体：认证、视频、上传、互动、关注、通知、管理等模块运行在一个 Spring Boot 应用中；转码和通知通过消息队列解耦。读路径采用 Caffeine 本地缓存 + Redis 分布式缓存的多级结构，热榜与视频列表均支持异步刷新（SWR）；异步任务通过 Transactional Outbox 保证事件不丢，可续期 Redis 锁防止并发转码，卡死兜底扫描器自动重投长时间未动的任务。这个形态便于本地部署，也为后续拆分独立 Worker 留出空间。

## 功能一览

| 模块 | 能力 |
|---|---|
| 用户与认证 | 注册、登录、JWT 鉴权与撤销、认证限流、普通用户/管理员权限、个人主页、密码重置申请 |
| 视频发现 | 首页推荐轮播、热门榜、分类筛选、关键词搜索、分页列表 |
| 投稿与播放 | 封面/视频上传、480P/720P/1080P 转码、自动截帧、Thumbnailator 封面处理、清晰度切换、MinIO 直连播放 |
| 审核与创作 | 投稿状态、审核通过/驳回、创作者视频管理、回收站与延迟清理、未投稿文件定时清理 |
| 社区互动 | 点赞、收藏、嵌套评论与回复、关注、粉丝列表 |
| 通知与运维 | 互动通知、未读数、管理员用户管理与密码重置、死信查看/忽略/重投、评论与视频管理 |

视频状态流转：

```text
上传 → PROCESSING → PENDING → PUBLISHED
                  ├→ PROCESS_FAILED
                  └→ REJECTED
```

## 页面与角色

| 页面 | 当前体验 |
|---|---|
| 首页 | 轮换视觉横幅、搜索、分区筛选、推荐列表与热门榜单；热门榜支持分页浏览。 |
| 视频详情 | 多清晰度播放（以转码结果为准）、播放参数展示、点赞、收藏、关注、嵌套评论与回复，以及二维码、QQ、QQ 空间、系统和链接分享。 |
| 创作与个人中心 | 预签名直传、视频投稿、转码/审核状态、稿件编辑与删除；查看点赞、收藏、关注/粉丝，并可申请密码重置。 |
| 消息与管理 | 登录用户可查看未读互动通知；管理员可审核投稿、管理评论和回收站、处理死信、查看用户及处理密码重置申请。 |

前端路由会将需要登录的页面重定向到登录页。管理操作还由后端权限校验保护，不能仅依赖前端入口隐藏。

## 技术栈

| 层级 | 技术 |
|---|---|
| 前端 | Vue 3、TypeScript、Vite、Vue Router、Axios、Element Plus |
| 后端 | Java 21、Spring Boot 4、Spring Security、JWT、MyBatis-Plus、HikariCP、Caffeine、Flyway |
| 数据与缓存 | MySQL 8.4、Redis 7.4、Lua、Redis ZSet、Redis Pipeline |
| 异步与存储 | RabbitMQ、MinIO、FFmpeg、Thumbnailator |
| 部署 | Docker Compose、Nginx、Maven、npm |

## 快速开始

### 前置条件

推荐通过 Docker Compose 启动全部服务：

- Docker Desktop / Docker Engine 与 Docker Compose v2
- 至少 4 GB 可用内存；首次启动需能够下载镜像

本地源码开发还需要 JDK 21、Node.js 20+、Maven 3.9+ 和 FFmpeg。

### 1. 配置环境变量

```powershell
Copy-Item deploy/server.env.example .env
```

仓库的环境变量模板位于 [`deploy/server.env.example`](deploy/server.env.example)，不在根目录提交 `.env.example`。编辑复制得到的 `.env`，替换所有示例密码和 `JWT_SECRET`；本地首次运行可保留其中的本机地址设置。不要提交包含真实密钥的 `.env`。

### 2. 启动服务

```powershell
docker compose up -d --build
docker compose ps
```

如果不希望 MySQL 暴露到宿主机端口（例如纯容器内压测、或避免与本地 MySQL 冲突），使用本项目提供的覆盖配置。它只移除 MySQL 的宿主机端口映射，容器间连接不受影响：

```powershell
docker compose -f docker-compose.yml -f docker-compose.benchmark.yml up -d --build
```

停止服务：

```powershell
docker compose down
```

### 本地打包、服务器只复制产物

适用于不希望服务器下载 Maven/npm 依赖的部署方式。本地 PowerShell 执行：

```powershell
.\scripts\deploy.ps1
```

该命令会完成后端测试与 Jar 构建、前端生产构建、打包、上传 `.env`、数据库增量迁移以及远程 Compose 重启。远程只重新构建 `backend` 和 `frontend`，RabbitMQ、MySQL、Redis、MinIO 会复用服务器已有镜像。常用参数：

```powershell
.\scripts\deploy.ps1 `
  -Server "82.157.205.6" `
  -RemoteUser "ubuntu" `
  -RemoteDir "/opt/videonest" `
  -IdentityFile "C:\keys\server.pem" `
  -PublicSiteUrl "https://video.example.com"
```

重复使用已生成的压缩包可加 `-SkipBuild`；紧急部署可用 `-SkipTests`；只有明确不需要执行数据库迁移时才使用 `-SkipMigrations`。也可以只生成部署包：

```powershell
.\scripts\package-deploy.ps1 -PublicSiteUrl "https://video.example.com"
```

服务器解压后，使用产物构建覆盖文件启动；后端镜像只复制 Jar，前端镜像只复制 `dist`：

```bash
cd /opt/videonest
tar -xzf /tmp/videonest-deploy.tar.gz -C /opt/videonest
sudo docker compose -f docker-compose.yml -f docker-compose.jar.yml up -d --build
```

该模式复用服务器已有的 `videonest-backend:latest` 运行镜像（其中包含 FFmpeg），因此部署构建不会再下载 Maven、npm 或 Alpine 的 FFmpeg 包。

### 服务地址

| 服务 | 地址 |
|---|---|
| VideoNest | `http://127.0.0.1` |
| 后端 API | `http://127.0.0.1:8080` |
| RabbitMQ 管理台 | `http://127.0.0.1:15672` |
| MinIO API / 管理台 | `http://127.0.0.1:9010` / `http://127.0.0.1:9011` |
| MySQL / Redis | `127.0.0.1:3307` / `127.0.0.1:6380` |

使用 `docker-compose.benchmark.yml` 覆盖配置时，MySQL 仅在 Docker 网络内可访问，不会监听宿主机端口。

首次启动后，后端会通过 Flyway 自动执行 `backend/src/main/resources/db/migration` 中的版本化迁移。一键部署会在迁移前备份数据库，并对历史迁移异常做兼容性检查；生产部署前仍建议自行确认备份可用。

## 本地开发

先启动基础设施：

```powershell
docker compose up -d mysql redis rabbitmq minio minio-init
```

启动后端：

```powershell
cd backend
mvn spring-boot:run
```

启动前端：

```powershell
cd frontend
npm install
npm run dev
```

开发前端默认监听 `http://127.0.0.1:5173`，并将 `/api` 代理到后端。

## 常用命令

```powershell
# 后端测试与打包
cd backend
mvn test
mvn package

# 前端构建
cd ../frontend
npm run build

# 构建全部容器镜像
cd ..
docker compose build
```

## API 模块

| 模块 | 接口前缀 | 示例能力 |
|---|---|---|
| 认证 | `/api/auth` | 注册、登录、密码重置申请 |
| 视频与分类 | `/api/videos`、`/api/categories` | 列表、详情、热门榜、分类 |
| 互动与评论 | `/api/videos/{videoId}`、`/api/videos/{videoId}/comments` | 点赞、收藏、嵌套评论、回复 |
| 上传与创作 | `/api/files`、`/api/creator` | 文件上传、投稿、创作者视频 |
| 用户关系与通知 | `/api/users`、`/api/notifications` | 关注、粉丝、通知、未读数 |
| 管理后台 | `/api/admin/videos`、`/api/admin/comments`、`/api/admin/dead-letters`、`/api/admin/users` | 审核、回收站、评论与死信管理、用户管理与密码重置 |

所有接口统一返回 `ApiResponse`。需登录的接口通过 `Authorization: Bearer <token>` 传递 JWT。

## 配置说明

完整模板见 [`deploy/server.env.example`](deploy/server.env.example)。常用变量如下：

| 分类 | 变量 |
|---|---|
| MySQL | `DB_NAME`、`DB_USERNAME`、`DB_PASSWORD`、`MYSQL_ROOT_PASSWORD`、`DB_POOL_MAX_SIZE`、`DB_POOL_MIN_IDLE` |
| Redis | `REDIS_USERNAME`、`REDIS_PASSWORD`、`REDIS_POOL_MAX_ACTIVE`、`REDIS_POOL_MAX_IDLE`、`REDIS_POOL_MIN_IDLE` |
| RabbitMQ | `RABBITMQ_USERNAME`、`RABBITMQ_PASSWORD` |
| MinIO | `MINIO_ACCESS_KEY`、`MINIO_SECRET_KEY`、`MINIO_BUCKET`、`MINIO_PUBLIC_ENDPOINT`、`MINIO_PUBLIC_READ_PREFIXES` |
| 缓存 | `HOT_RANK_REFRESH_INTERVAL_MS`、`HOT_RANK_LOCAL_CACHE_MILLISECONDS`、`VIDEO_LIST_CACHE_TTL_SECONDS`、`VIDEO_LIST_CACHE_LOCAL_MAX_SIZE`、`VIDEO_LIST_CACHE_LOCAL_SOFT_TTL_SECONDS`、`COMMENT_LIST_CACHE_TTL_SECONDS` |
| 安全 | `JWT_SECRET`、`ANTIVIRUS_COMMAND`、`ANTIVIRUS_REQUIRED`、`UPLOAD_SCAN_TIMEOUT_SECONDS` |
| 视频处理 | `VIDEO_PROCESS_CONSUMER_CONCURRENCY`、`FFPROBE_PATH`、`VIDEO_VIEW_DEDUP_WINDOW_SECONDS` |
| 业务规则 | `VIDEO_REVIEW_TIMEOUT_MILLISECONDS`、`RESOURCE_RETENTION_DAYS`、`ANONYMOUS_VIEW_LIMIT_PER_MINUTE` |
| 服务器 | `HTTP_PORT`、`TOMCAT_MAX_THREADS`、`TOMCAT_MIN_SPARE_THREADS` |

生产环境应配置强密码、HTTPS、对象存储与 RabbitMQ/MySQL 的网络访问限制、上传病毒扫描、限流、日志脱敏及备份策略。

## 性能验证

项目附带可复现的只读并发压测脚本：

```powershell
# 完整套件：约 7 分钟
node scripts/run-performance-suite.js

# 快速回归：约 100 秒
node scripts/run-performance-suite.js --quick
```

完整套件覆盖首页、热门视频、视频列表、分类、评论和 100/200/400 并发混合流量。它先进行健康预检，再生成 Markdown 报告和原始 JSON；不会调用写接口。

2026-09-04 的只读压测记录（经 Nginx 入口；发压机与被测服务位于同一主机）如下：

| 场景 | 结果 |
|---|---|
| 全量只读测试 | 16 个场景、0 个失败场景、健康预检通过 |
| 热门视频（100 并发） | 319.16 QPS，100% 成功，P99 776.64 ms |
| 视频列表（100 并发） | 107.33 QPS，99.58% 成功，P99 6040.67 ms |
| 评论列表（100 并发） | 467.04 QPS，100% 成功，P99 1670.03 ms |
| 混合只读流量（200 并发） | 197.91 QPS，99.36% 成功，P99 8639.01 ms |

详情、边界和复现说明见 [压测报告 2026-09-04](docs/performance-test-2026-09-04.md)。更早的本机 Docker 热缓存基线见 [压测报告 2026-08-02](docs/performance-test-2026-08-02.md)。这些结果仅代表对应测试环境，不构成生产容量承诺；生产评估应使用独立发压机、接近生产的数据规模以及 10～30 分钟以上的读写混合流量。

### 写链路压测资产

`benchmark/` 保存 JMeter 5.6.3 测试计划，覆盖注册、登录、热门榜、上传预签名、上传完成回调和投稿发布。其中写接口会创建或读取测试数据，必须只在隔离环境执行；仓库提供的 `docker-compose.test.yml` 会切换到测试 MySQL 库、Redis DB、RabbitMQ vhost 与 MinIO bucket，并关闭认证限流以便测量服务自身吞吐。不要将该配置用于公网或生产环境。

当前认证密码编码器使用 BCrypt cost 8（`2^8` 轮）以降低注册、登录的 CPU 压力。若用于真实生产账号，应结合机器规格、攻击面、限流和延迟目标重新评估该成本，而非把压测配置直接视为安全基线。

## 项目结构

```text
videonest/
├─ backend/                     # Spring Boot 后端
│  ├─ src/main/java/.../module/ # auth、video、upload、interaction、follow、notification、admin
│  ├─ src/main/resources/       # 配置、MyBatis Mapper 与 Flyway 迁移脚本
│  └─ src/test/                 # 自动化测试
├─ frontend/                    # Vue 3 前端与 Nginx 配置
├─ deploy/                      # 独立基础设施部署文件与环境变量模板
│  └─ server.env.example         # 环境变量模板（复制为根目录 .env）
├─ benchmark/                   # JMeter 写链路压测计划
├─ docs/                        # 截图、压测报告、可靠性设计文档
├─ scripts/                     # 可复现压测脚本、部署脚本与本地启动脚本
│  └─ start-backend.ps1         # 本地一键加载 .env 并启动后端
├─ sql/                         # 初始化与增量 SQL
├─ docker-compose.yml           # 完整服务编排
├─ docker-compose.benchmark.yml # 本机端口冲突覆盖配置
├─ docker-compose.jar.yml       # 服务器仅复制产物的覆盖配置
└─ docker-compose.test.yml      # 隔离环境写链路压测配置
```

## 技术文档

| 文档 | 说明 |
|---|---|
| [后端可靠性设计](docs/backend-reliability-design.md) | HTTP 状态码、JWT 撤销、认证限流、Flyway、Transactional Outbox |
| [工程加固记录 2026-08-02](docs/engineering-hardening-2026-08-02.md) | 上线前的工程化治理项 |
| [性能监控方案](docs/performance-monitoring.md) | 监控指标与采集方式 |
| [压测报告合集](docs/performance-test-2026-09-04.md) | 历次只读压测结果与复现步骤 |

## 当前边界

- 当前为单实例模块化单体，未提供服务级高可用。
- 转码会受单机 CPU、内存和 FFmpeg 并发限制；大量投稿会在队列中排队。
- 标题搜索为 MySQL 模糊匹配；大规模全文检索可接入 Elasticsearch。
- 视频流在生产环境应配合 CDN、独立对象存储与带宽规划。
- 写接口、登录与上传/转码需要在隔离环境中独立进行容量与故障恢复测试。

## 安全提示

- 不要提交 `.env`、真实密码、JWT 密钥或 MinIO 密钥。
- 生产环境必须替换所有示例凭据，并限制数据库、消息队列和对象存储的公网访问。
- 上传接口应启用病毒扫描；公网部署应启用 HTTPS、限流、CORS 白名单与审计日志。
